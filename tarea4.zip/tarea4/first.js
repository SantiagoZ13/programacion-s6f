// Ejercicio 1
// Escriba un programa que muestre la longitud de un texto introducido por el usuario.
let something = prompt("Escribe algo");

alert("El largo del texto insertado es: " + something.length);

// Ejercicio 2
// Escriba expresiones que den True o False
a = "Hola";
b = "Mundo";
c = "Mundo";
d = 1;
e = "1";
// 1. Compare dos string y que de TRUE
if (b === c) {
  alert("b es igual a c TRUE");
}
// 2. Compare dos string y que de FALSE
if (a === c) {
  alert("a es igual a c TRUE");
}
// 3. String y numero y de TRUE
if (d == e) {
  alert("d es igual a e TRUE");
}
// 4. String y numero y de FALSE
if (a == d) {
  alert("a  no es igual a d FALSE");
}
