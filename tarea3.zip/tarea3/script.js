let userName = "Sanma";
let userLastname = "Smith";

console.log(userName + userLastname);
