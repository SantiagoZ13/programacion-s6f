userName = prompt("¿Cuál es tu nombre?");
userLastname = prompt("¿Cuál es tu apellido?");
alert(`Bienvenido a mi página ${userName} ${userLastname}`);
